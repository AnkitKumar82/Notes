package com.example.notes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;
public class NotesArrayAdapter extends ArrayAdapter<Note> implements Filterable{
    private Context mContext;
    private ArrayList<Note> fitems;
    private ArrayList<Note> original;
    private noteFilter filter;
    int mResource;
    public NotesArrayAdapter(Context context, int resource, ArrayList<Note> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.mResource  = resource;
        this.fitems = new ArrayList<Note>(objects);
        this.original = new ArrayList<Note>(objects);
    }
    public void updateInternalData(int index, @Nullable Note object, int opr){
        if(opr==1) {
            this.original.add(0, object);
        }
        else{
            this.original.remove(index);
        }
    }
    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String noteValue = getItem(position).getNote();
        String timestampValue = getItem(position).getNoteTimestamp();
        Note note = new Note(noteValue,timestampValue);
        LayoutInflater inflater  = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource,parent,false);
        TextView noteTextView = (TextView) convertView.findViewById(R.id.noteMainTextView);
        TextView noteTimestampTextView = (TextView) convertView.findViewById(R.id.timestampMainTextView);
        noteTextView.setText(noteValue);
        noteTimestampTextView.setText(timestampValue);
        return convertView;
    }
    @Override
    public Filter getFilter(){
        if (filter == null){
            filter = new noteFilter();
        }
        return filter;
    }

    private class noteFilter extends Filter{
        @Override
        protected FilterResults performFiltering(CharSequence constraint){
            FilterResults results = new FilterResults();
            String prefix = constraint.toString().toLowerCase();
            if (prefix == null || prefix.length() == 0){
                ArrayList<Note> list = new ArrayList<Note>(original);
                results.values = list;
                results.count = list.size();
            }
            else{
                final ArrayList<Note> list = new ArrayList<Note>(original);
                final ArrayList<Note> nlist = new ArrayList<Note>();
                int count = list.size();
                for (int i=0; i<count; i++){
                    final Note note = list.get(i);
                    final String value = note.getNote().toLowerCase();
                    if (value.contains(prefix)){
                        nlist.add(note);
                    }
                }
                results.values = nlist;
                results.count = nlist.size();
            }
            return results;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            fitems = (ArrayList<Note>)results.values;
            notifyDataSetChanged();
            clear();
            int count = fitems.size();
            for (int i = 0; i < count; i++) {
                Note note = (Note) fitems.get(i);
                add(note);
            }
            notifyDataSetInvalidated();
        }
    }
}
