package com.example.notes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import static com.example.notes.MainActivity.adapter;
import static com.example.notes.MainActivity.notes;

public class noteEditor extends AppCompatActivity {
    private EditText editText;
    private TextView textView;
    private TextView charCount;
    private int id_key;
    private DBhandler dbhandler;
    private String noteValue;
    Note note;
    private String timestampValue;
    private int id_key_index;
    private final TextWatcher mTextEditorWatcher = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            charCount.setText("  |  "+String.valueOf(s.length())+" Characters");
        }
        public void afterTextChanged(Editable s) {
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adapter.notifyDataSetChanged();
        setContentView(R.layout.activity_note_editor);
        editText = findViewById(R.id.note_edittext);
        textView = findViewById(R.id.note_textview);
        charCount = findViewById(R.id.charCountView);
        Intent mIntent = getIntent();
        id_key_index = mIntent.getIntExtra("ID",0);
        id_key = notes.get(id_key_index).getNoteId();
        dbhandler = new DBhandler(this);
        note = dbhandler.getNote(id_key);
        noteValue = note.getNote();
        charCount.setText("  |  "+String.valueOf(noteValue.length())+" Characters");
        timestampValue = note.getNoteTimestamp();
        editText.setText(noteValue);
        editText.setSelection(noteValue.length());
        textView.setText(String.valueOf(timestampValue));
        editText.addTextChangedListener(mTextEditorWatcher);
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        String str = editText.getText().toString();
        if(str.length()<=0){
            notes.remove(id_key_index);
            adapter.notifyDataSetChanged();
            dbhandler.deleteNote(note);
            finish();
        }
        else{
            if(noteValue.equals(str)){
                finish();
            }
            else {
                note.setNote(str);
                note.setNoteTimestamp();
                notes.remove(id_key_index);
                notes.add(0, note);
                adapter.updateInternalData(0,note,1);
                adapter.notifyDataSetChanged();
                dbhandler.updateNote(note);
                finish();
            }
        }
    }
}
