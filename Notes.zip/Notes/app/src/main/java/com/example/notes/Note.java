package com.example.notes;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Note {
    public int noteId;
    public String note;
    public String noteTimestamp;
    public Note(){
        this.note="";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        this.noteTimestamp = sdf.format(new Date());
    }
    public Note(int vNoteId,String vNote,String vNoteTimestamp){
        this.note = vNote;
        this.noteId = vNoteId;
        this.noteTimestamp = vNoteTimestamp;
    }
    public Note(String vNote,String vNoteTimestamp){
        this.note = vNote;
        this.noteTimestamp = vNoteTimestamp;
    }
    public int getNoteId(){
        return noteId;
    }
    public void setNoteId(int vNoteId){
        this.noteId = vNoteId;
    }
    public String getNoteTimestamp(){
        return noteTimestamp;
    }
    public void setNoteTimestamp(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        this.noteTimestamp = sdf.format(new Date());
    }
    public void setNoteTimestamp(String vTimestamp){
        noteTimestamp = vTimestamp;
    }
    public String getNote(){
        return note;
    }
    public void setNote(String vNote){
        note = vNote.trim();        //to removing starting and ending spaces
    }
}
