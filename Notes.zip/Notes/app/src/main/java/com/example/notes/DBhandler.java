package com.example.notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;

import androidx.annotation.Nullable;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import static android.content.Context.MODE_PRIVATE;

public class DBhandler extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DB_Name = "NotesDB";
    private static final String NOTES_TABLE = "notes";
    private static final String ID = "id";
    private static final String NOTE = "note";
    private static final String TIMESTAMP = "timestamp";


    public DBhandler(@Nullable  Context context){
        super(context,DB_Name,null,VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_NOTES_TABLE = "CREATE TABLE IF NOT EXISTS " + NOTES_TABLE + "("
                            +ID +" integer PRIMARY KEY autoincrement , "
                            +NOTE + " TEXT ,"
                            +TIMESTAMP + " TEXT )";
        db.execSQL(CREATE_NOTES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql = "DROP TABLE " + NOTES_TABLE;
        db.execSQL(sql);
        onCreate(db);
    }
    public Note addNote(Note note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        note.setNoteTimestamp();
        values.put(NOTE, note.getNote());
        values.put(TIMESTAMP, note.getNoteTimestamp());
        db.insert(NOTES_TABLE, null, values);
        Note noteReturn=null;
        String sql = "SELECT * FROM " + NOTES_TABLE + " WHERE " + ID +" = (SELECT MAX("+ID+") FROM "+NOTES_TABLE+")";
        Cursor cursor = db.rawQuery(sql,null);
        if (cursor != null) {
            cursor.moveToFirst();
            noteReturn = new Note(
                    Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1),
                    cursor.getString(2)
            );
        }
        return noteReturn;
    }
    public Note getNote(int id){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                NOTES_TABLE , new String[]{ID,NOTE,TIMESTAMP},
        ID+"=?",new String[] {String.valueOf(id)},
        null,null,null,null);
        Note note;
        if(cursor!=null){
            cursor.moveToFirst();
            note = new Note(
                    Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1),
                    cursor.getString(2)
            );
         return note;
        }else{
            return null;
        }
    }
    public ArrayList<Note> getAllNotes(){
        SQLiteDatabase db = getReadableDatabase();
        ArrayList <Note> notes = new ArrayList<>();
        String query = "SELECT * FROM "+ NOTES_TABLE;
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                Note note = new Note();
                note.setNoteId(Integer.parseInt(cursor.getString(0)));
                note.setNote(cursor.getString(1));
                note.setNoteTimestamp(cursor.getString(2) );
                notes.add(note);
            }while(cursor.moveToNext());
        }
        Collections.sort(notes, new Comparator<Note>() {
            @Override
            public int compare(Note note1, Note note2) {
                return note1.getNoteTimestamp().compareTo(note2.getNoteTimestamp());
            }
        });
        return notes;
    }
    public int updateNote(Note note){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NOTE,note.getNote());
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        values.put(TIMESTAMP, sdf.format(new Date()));
        return db.update(
                NOTES_TABLE,
                values,
                ID + " = ?",
                new String[]{String.valueOf(note.getNoteId())});
    }
    public void deleteNote(Note note){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(
                NOTES_TABLE,
                ID + " = ?",
                new String[]{String.valueOf(note.getNoteId())}
        );
        db.close();
    }
    public int getNotesCount(){
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT * From " + NOTES_TABLE;
        Cursor cursor = db.rawQuery(query,null);
        return cursor.getCount();
    }
}
